"""
steelbeam - Eng. Rocco Raimo
---
A python package for calculation of resistance and stability of steel beams, based on multiple national codes.
---

The module analysis_EC.py contains the beam analysis for the beam object based on Eurocodes.

"""

from handcalcs.decorator import handcalc
import handcalcs
handcalcs.set_option("custom_symbols", {"C": ","})

from math import pi
from numpy import sqrt

# ----- RESISTANCE

def normal_force_tension(self, a_net=None, render=False, preferred_units=None, precision=3):
    """

    EC3 1993-1-1:2005 - § 6.2.3
    
    """
    if a_net is None:
        a_net = self.section_area
    gamma_m0 = self._partial_factors.get('gamma_m0', 1.05)
    gamma_m2 = self._partial_factors.get('gamma_m2', 1.25)

    if render==False:
        n_pl = (self.section_area * self.f_yk / gamma_m0).to_preferred(preferred_units)
        n_u = (0.9 * a_net * self.f_yk / gamma_m2).to_preferred(preferred_units)
        normal_force_tension = (min(n_pl, n_u)).to_preferred(preferred_units)
        return normal_force_tension
        
    elif render==True:
        @handcalc(override= "", precision= precision, left= "", right= "", jupyter_display=True)
        def render_instance(A, f_yk, A_net):
            """
            """
            N_plCRd = A * f_yk / gamma_m0; N_plCRd = (A * f_yk / gamma_m0).to_preferred(preferred_units)
            N_uCRd = 0.9 * A_net * f_yk / gamma_m2; N_uCRd = (0.9 * A_net * f_yk / gamma_m2).to_preferred(preferred_units)
            N_tCRd = min(N_plCRd, N_uCRd); N_tCRd = (min(N_plCRd, N_uCRd)).to_preferred(preferred_units)
        return render_instance(self.section_area, self.f_yk, a_net)
        

def normal_force_compression(self, render = False, preferred_units=None, precision: int = 3):
    """

    EC3 1993-1-1:2005 - § 6.2.4
    (ONLY CROSS-SECTIONS IN CLASS 1, 2 OR 3)

    """
    gamma_m0 = self._partial_factors.get('gamma_m0', 1.05)

    if render==False:
        normal_force_compression = (self.section_area * self.f_yk / gamma_m0).to_preferred(preferred_units)
        return normal_force_compression
    elif render==True:
        @handcalc(override= "", precision= precision, left= "", right= "", jupyter_display=True)
        def render_instance(A, f_yk):
            """
            """
            N_cCRd = A * f_yk / gamma_m0; N_cCRd = (A * f_yk / gamma_m0).to_preferred(preferred_units)
        return render_instance(self.section_area, self.f_yk)  

def bending_moment_y(self, render = False, preferred_units=None, precision: int = 3):
    """
    Bending moment around y axis (along z axis)
    EC3 1993-1-1:2005 - § 6.2.5
    (ONLY CROSS-SECTIONS IN CLASS 1 OR 2)

    """
    gamma_m0 = self._partial_factors.get('gamma_m0', 1.05)
    if render==False:
        bending_moment_y = (self.section_w_pl_y * self.f_yk / gamma_m0).to_preferred(preferred_units)
        return bending_moment_y
    elif render==True:
        @handcalc(override= "", precision= precision, left= "", right= "", jupyter_display=True)
        def render_instance(W_plCy, f_yk):
            """
            """
            M_cCRdCy = W_plCy * f_yk / gamma_m0; M_cCRdCy = (W_plCy * f_yk / gamma_m0).to_preferred(preferred_units)
        return render_instance(self.section_w_pl_y, self.f_yk)


def bending_moment_z(self, render = False, preferred_units=None, precision: int = 3):
    """
    Bending moment around z axis (along y axis)
    EC3 1993-1-1:2005 - § 6.2.5
    (ONLY CROSS-SECTIONS IN CLASS 1 OR 2)

    """
    gamma_m0 = self._partial_factors.get('gamma_m0', 1.05)
    if render==False:
        bending_moment_z = (self.section_w_pl_z * self.f_yk / gamma_m0).to_preferred(preferred_units)
        return bending_moment_z
    elif render==True:
        @handcalc(override= "", precision= precision, left= "", right= "", jupyter_display=True)
        def render_instance(W_plCz, f_yk):
            """
            """
            M_cCRdCz = W_plCz * f_yk / gamma_m0; M_cCRdCz = (W_plCz * f_yk / gamma_m0 ).to_preferred(preferred_units)
        return render_instance(self.section_w_pl_z, self.f_yk)    

def shear_y(self, render = False, preferred_units=None, precision: int = 3):
    """

    EC3 1993-1-1:2005 - § 6.2.6

    """
    gamma_m0 = self._partial_factors.get('gamma_m0', 1.05)
    if render==False:
        shear_y = (self.section_area_shear_y * (self.f_yk / sqrt(3)) / gamma_m0).to_preferred(preferred_units)
        return shear_y
    elif render==True:
        @handcalc(override= "", precision= precision, left= "", right= "", jupyter_display=True)
        def render_instance(A_vCy, f_yk):
            """
            """
            V_cCRdCy = A_vCy * (f_yk / sqrt(3)) / gamma_m0; V_cCRdCy = (A_vCy * (f_yk / sqrt(3)) / gamma_m0).to_preferred(preferred_units)
        return render_instance(self.section_area_shear_y, self.f_yk)            

def shear_z(self, render = False, preferred_units=None, precision: int = 3):
    """
    
    EC3 1993-1-1:2005 - § 6.2.6

    """
    gamma_m0 = self._partial_factors.get('gamma_m0', 1.05)
    if render==False:
        shear_z = (self.section_area_shear_z * (self.f_yk / sqrt(3)) / gamma_m0).to_preferred(preferred_units)
        return shear_z
    elif render==True:
        @handcalc(override= "", precision= precision, left= "", right= "", jupyter_display=True)
        def render_instance(A_vCz, f_yk):
            """
            """
            V_cCRdCz = A_vCz * (f_yk / sqrt(3)) / gamma_m0; V_cCRdCz = (A_vCz * (f_yk / sqrt(3)) / gamma_m0).to_preferred(preferred_units)
        return render_instance(self.section_area_shear_z, self.f_yk)            

# INTERACTION BETWEEN STRESS CHARACTERISTICS

## Bending and axial force
def bending_moment_axial_y(self, render = False, preferred_units=None, precision: int = 3, n_ed: float = 0):
    """
    Bending moment around y axis (along z axis) with simultaneous axial force
    EC3 1993-1-1:2005 - § 6.2.9
    (ONLY CROSS-SECTIONS IN CLASS 1 OR 2)

    """
    if n_ed == 0:
        raise ValueError(f"The normal force cannot be 0")
    
    gamma_m0 = self._partial_factors.get('gamma_m0', 1.05)
    n_pl_rd = self.section_area * self.f_yk / gamma_m0
    if render==False:
        # Check for web dimensions (for I-sections)
        web_check = 0.5 * self.h_w * self.t_w * self.f_yk / gamma_m0 if self.h_w is not None and self.t_w is not None else float('inf')
        if n_ed <= 0.25 * n_pl_rd and n_ed <= web_check:
            bending_moment_y = (self.section_w_pl_y * self.f_yk / gamma_m0).to_preferred(preferred_units)
        else:
            # For higher axial forces, the moment capacity is reduced
            # This is a simplified implementation; full interaction should be implemented
            n = n_ed / n_pl_rd
            a = (self.section_area - 2*self.b*self.t_f) / self.section_area if self.b is not None and self.t_f is not None else 0
            k =  (1 - n) / (1 - 0.5*a) 
            m_pl_rd_y = self.section_w_pl_y * self.f_yk / gamma_m0 
            bending_moment_y = m_pl_rd_y * k
            if bending_moment_y > m_pl_rd_y:
                bending_moment_y = m_pl_rd_y
        return (bending_moment_y).to_preferred(preferred_units)
    elif render==True:
        m_pl_rd_y = self.section_w_pl_y * self.f_yk / gamma_m0 
        @handcalc(override= "", precision= precision, left= "", right= "", jupyter_display=True)
        def render_instance(N_Ed, N_plCRd, W_plCy, f_yk, A, b, t_f):
            """
            """
            n = N_Ed / N_plCRd
            a = (A - 2*b*t_f) / A
            k =  (1 - n) / (1 - 0.5*a) 
            M_plCRdCy = W_plCy * f_yk / gamma_m0; M_plCRdCy = (W_plCy * f_yk / gamma_m0).to_preferred(preferred_units)
            M_NCy = M_plCRdCy * k; M_NCy = (M_plCRdCy * k).to_preferred(preferred_units)
        return render_instance(n_ed, n_pl_rd, self.section_w_pl_y, self.f_yk, self.section_area, self.b, self.t_f)

def bending_moment_axial_z(self, render = False, preferred_units=None, precision: int = 3, n_ed: float = 0):
    """
    Bending moment around z axis (along y axis) with simultaneous axial force
    EC3 1993-1-1:2005 - § 6.2.9
    (ONLY CROSS-SECTIONS IN CLASS 1 OR 2)

    """
    if n_ed == 0:
        raise ValueError(f"The normal force cannot be 0")

    gamma_m0 = self._partial_factors.get('gamma_m0', 1.05)
    n_pl_rd = self.section_area * self.f_yk / gamma_m0
    if render==False:
        web_check = 0.5 * self.h_w * self.t_w * self.f_yk / gamma_m0 if self.h_w is not None and self.t_w is not None else float('inf')
        if n_ed <= web_check:
            bending_moment_z = self.section_w_pl_z * self.f_yk / gamma_m0
        else:
            # For higher axial forces, the moment capacity is reduced
            # This is a simplified implementation; full interaction should be implemented
            n = n_ed / n_pl_rd
            a = (self.section_area - 2*self.b*self.t_f) / self.section_area if self.b is not None and self.t_f is not None else 0
            k =  1 - ((n - a) / (1 - a))**2 
            m_pl_rd_z = self.section_w_pl_y * self.f_yk / gamma_m0 
            if n <= a: bending_moment_z = m_pl_rd_z
            elif n > a: bending_moment_z = m_pl_rd_z * k
        return bending_moment_z
    elif render==True:
        m_pl_rd_z = self.section_w_pl_y * self.f_yk / gamma_m0 
        @handcalc(override= "", precision= precision, left= "", right= "", jupyter_display=True)
        def render_instance(N_Ed, N_plCRd, W_plCz, f_yk, A, b, t_f):
            """
            """
            n = N_Ed / N_plCRd
            a = (A - 2*b*t_f) / A
            k =  1 - ((n - a) / (1 - a))**2 
            M_plCRdCz = W_plCz * f_yk / gamma_m0; M_plCRdCz = (W_plCz * f_yk / gamma_m0).to_preferred(preferred_units)
            M_NCz = M_plCRdCz * k; M_NCz = (M_plCRdCz * k).to_preferred(preferred_units)
        return render_instance(n_ed, n_pl_rd, self.section_w_pl_z, self.f_yk, self.section_area, self.b, self.t_f)

## Bending and shear

## Torsion

# ----- STABILITY

def eulerian_critic_load(self, render = False, preferred_units=None, precision: int = 3):
    """
    """
    if render==False:    
        n_cr_y = (pi**2 * self.elastic_modulus * self.section_inertia_y) / (self.length)**2
        n_cr_z = (pi**2 * self.elastic_modulus * self.section_inertia_z) / (self.length)**2
        n_cr = min(n_cr_y, n_cr_z)
        return n_cr
    elif render==True:
        @handcalc(override= "", precision= precision, left= "", right= "", jupyter_display=True)
        def render_instance(E, I_y, I_z, L_0):
            """
            """
            N_crCy = ((pi**2 * E * I_y) / L_0**2); N_crCy = (((pi**2 * E * I_y) / L_0**2)).to_preferred(preferred_units)
            N_crCz = ((pi**2 * E * I_z) / L_0**2); N_crCz = (((pi**2 * E * I_z) / L_0**2)).to_preferred(preferred_units)
            N_cr = min(N_crCy, N_crCz); N_cr = (min(N_crCy, N_crCz)).to_preferred(preferred_units)
        return render_instance(self.elastic_modulus, self.section_inertia_y, self.section_inertia_z, self.length)            

def slenderness_relative(self):
    """"
    """
    lambda_relative = sqrt(self.section_area * self.f_yk / self.eulerian_critic_load())
    return lambda_relative

def normal_force_buckling(self, buckling_curve: str, render = False, preferred_units=None, precision: int = 3):
    """

    Buckling resistance for uniform members in compression
    EC3 1993-1-1:2005 - § 6.3.1
  
    """
    gamma_m1 = self._partial_factors.get('gamma_m0', 1.10)
    imperfection_factors = {
    'a0': 0.13,
    'a': 0.21,
    'b': 0.34,
    'c': 0.49,
    'd': 0.76
    }
    alpha = imperfection_factors.get(buckling_curve)
    lambd = self.slenderness_relative()
    if render==False:
        psi = 0.5*(1+alpha*(lambd-0.2)+lambd**2)
        chi = 1/ (psi+sqrt(psi**2 - lambd**2))
        N_bRd = (chi * self.section_area * self.f_yk / gamma_m1).to_preferred(preferred_units)
        return N_bRd
    if render==True:
            @handcalc(override= "", precision= precision, left= "", right= "", jupyter_display=True)
            def render_instance(A, f_yk, alpha, lamb):
                """
                """
                Phi = 0.5*(1+alpha*(lamb-0.2)+lamb**2)
                chi = 1/ (Phi+sqrt(Phi**2 - lamb**2))
                N_bcRd = chi * A * f_yk / gamma_m1; N_bcRd = (chi * A * f_yk / gamma_m1).to_preferred(preferred_units)
            return render_instance(self.section_area, self.f_yk, alpha, lambd)


def bending_moment_buckling_y(self, psi_1:float = 1.0 , k_c: float = 1.0, buckling_curve_lt: str = 'a', beta:float = 1.0, render = False, preferred_units=None, precision: int = 3):
    """
    
    Buckling resistance for uniform members in bending with action along y axis
    EC3 1993-1-1:2005 - § 6.3.2
  
    """
    gamma_m1 = self._partial_factors.get('gamma_m0', 1.10)
    imperfection_factors = {
    'a': 0.21,
    'b': 0.34,
    'c': 0.49,
    'd': 0.76
    }
    alpha_lt = imperfection_factors.get(buckling_curve_lt)
    l_cr = self.length * beta
    lamb_lt_0 = 0.2
    if render==False:
        # Approximation without taking warping stiffness into account
        m_cr = psi_1 * (pi/l_cr) * sqrt(self.elastic_modulus * self.section_inertia_y * self.shear_modulus * self.section_inertia_torsional)
        lambd_lt = sqrt(self.section_w_pl_y* self.f_yk/m_cr)
        phi_lt = 0.5*(1+alpha_lt*(lambd_lt-lamb_lt_0)+beta*lambd_lt**2)
        f = 1-0.5*(1-k_c)*(1-2*(lambd_lt-0.8)**2)
        chi_lt = (1/f)* (1/ (phi_lt+sqrt(phi_lt**2 - beta*lambd_lt**2)))
        M_bRd = (chi_lt * self.section_w_pl_y * self.f_yk / gamma_m1).to_preferred(preferred_units)
        return M_bRd
    elif render==True:
        @handcalc(override= "", precision= precision, left= "", right= "", jupyter_display=True)
        def render_instance(f_yk, E, G, I_y, I_T, W_plCy, L_cr, alpha_LT, lamb_LTc0):
            """
            """
            M_cr = psi_1 * (pi/L_cr) * sqrt(E * I_y * G * I_T)
            lamb_LT = sqrt(W_plCy* f_yk/M_cr)
            phi_LT = 0.5*(1+alpha_LT*(lamb_LT-lamb_LTc0)+beta*lamb_LT**2)
            f = 1-0.5*(1-k_c)*(1-2*(lamb_LT-0.8)**2)
            chi_LT = (1/f)* (1/ (phi_LT+sqrt(phi_LT**2 - beta*lamb_LT**2)))
            M_bCRd = chi_LT * W_plCy * f_yk / gamma_m1; M_bCRd = (chi_LT * W_plCy * f_yk / gamma_m1).to_preferred(preferred_units)
        return render_instance(self.f_yk, self.elastic_modulus, self.shear_modulus, self.section_inertia_y, self.section_inertia_torsional, self.section_w_pl_y, l_cr, alpha_lt, lamb_lt_0)
        

def bending_moment_buckling_z(self, psi_1:float = 1.0 , k_c: float = 1.0, buckling_curve_lt: str = 'a', beta:float = 1.0, render = False, preferred_units=None, precision: int = 3):
    """
    
    Buckling resistance for uniform members in bending with action along z axis
    EC3 1993-1-1:2005 - § 6.3.2

    """
    gamma_m1 = self._partial_factors.get('gamma_m0', 1.10)
    imperfection_factors = {
    'a': 0.21,
    'b': 0.34,
    'c': 0.49,
    'd': 0.76
    }
    alpha_lt = imperfection_factors.get(buckling_curve_lt)
    l_cr = self.length * beta
    lamb_lt_0 = 0.2
    if render==False:
        # Approximation without taking warping stiffness into account
        m_cr = psi_1 * (pi/l_cr) * sqrt(self.elastic_modulus * self.section_inertia_z * self.shear_modulus * self.section_inertia_torsional)
        lambd_lt = sqrt(self.section_w_pl_z* self.f_yk/m_cr)
        phi_lt = 0.5*(1+alpha_lt*(lambd_lt-lamb_lt_0)+beta*lambd_lt**2)
        f = 1-0.5*(1-k_c)*(1-2*(lambd_lt-0.8)**2)
        chi_lt = (1/f)* (1/ (phi_lt+sqrt(phi_lt**2 - beta*lambd_lt**2)))
        M_bRd = (chi_lt * self.section_w_pl_z * self.f_yk / gamma_m1).to_preferred(preferred_units)
        return M_bRd
    elif render==True:
        @handcalc(override= "", precision= precision, left= "", right= "", jupyter_display=True)
        def render_instance(f_yk, E, G, I_z, I_T, W_plCz, L_cr, alpha_LT, lamb_LTc0):
            """
            """
            M_cr = psi_1 * (pi/L_cr) * sqrt(E * I_z * G * I_T)
            lamb_LT = sqrt(W_plCz* f_yk/M_cr)
            phi_LT = 0.5*(1+alpha_LT*(lamb_LT - lamb_LTc0)+beta*lamb_LT**2)
            f = 1-0.5*(1-k_c)*(1-2*(lamb_LT-0.8)**2)
            chi_LT = (1/f)* (1/ (phi_LT+sqrt(phi_LT**2 - beta*lamb_LT**2)))
            M_bCRd = chi_LT * W_plCz * f_yk / gamma_m1; M_bCRd = (chi_LT * W_plCz * f_yk / gamma_m1).to_preferred(preferred_units)
        return render_instance(self.f_yk, self.elastic_modulus, self.shear_modulus, self.section_inertia_z, self.section_inertia_torsional, self.section_w_pl_z, l_cr, alpha_lt, lamb_lt_0)